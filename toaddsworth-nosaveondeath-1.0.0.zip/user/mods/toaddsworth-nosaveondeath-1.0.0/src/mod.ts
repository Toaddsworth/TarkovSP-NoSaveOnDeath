import { DependencyContainer } from "tsyringe";
import { IPreAkiLoadMod } from "@spt-aki/models/external/IPreAkiLoadMod";
import { InraidController } from "@spt-aki/controllers/InraidController";
import { ISaveProgressRequestData } from "@spt-aki/models/eft/inRaid/ISaveProgressRequestData";
import { PlayerRaidEndState } from "@spt-aki/models/enums/PlayerRaidEndState";
 
// create an interface for the InraidController so we can add a method to it
declare module "@spt-aki/controllers/InraidController"
{
    interface InraidController 
    {
        savePostRaidProgressIfLived(
            offraidData: ISaveProgressRequestData, 
            sessionID: string): void;
    }
}
// prototype the newly added method. copies the code of the original, but 
// does not execute unless the player survived or ran through
InraidController.prototype.savePostRaidProgressIfLived = function(
    offraidData: ISaveProgressRequestData, 
    sessionID: string)
{
    const isDead = (offraidData.exit !== PlayerRaidEndState.SURVIVED && 
        offraidData.exit !== PlayerRaidEndState.RUNNER);
    if (!isDead)
    {
        this.logger.debug(`Raid outcome: ${offraidData.exit}`);

        if (!this.inraidConfig.save.loot)
        {
            return;
        }

        if (offraidData.isPlayerScav)
        {
            this.savePlayerScavProgress(sessionID, offraidData);
        }
        else
        {
            this.savePmcProgress(sessionID, offraidData);
        }
    }
}

class NoSaveOnDeath implements IPreAkiLoadMod
{
    private static container: DependencyContainer;
    
    public preAkiLoad(container: DependencyContainer): void 
    {
        NoSaveOnDeath.container = container;

        container.afterResolution("InraidController", (_t, result: InraidController) => 
        {
            result.savePostRaidProgress = (
                offraidData: ISaveProgressRequestData, 
                sessionID: string) => 
            {
                // replace method with the interface method we created above
                return result.savePostRaidProgressIfLived(offraidData, sessionID);
            }
        }, {frequency: "Always"});
    }
}

module.exports = { mod: new NoSaveOnDeath() }